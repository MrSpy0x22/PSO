'use strict';

/* Funkcje muszą być wczytane przed GUI !!! */

const GUI = {

    // Flex-y
    sb_cont: document.getElementById("c-sidebar") ,
    co_cont: document.getElementById("c-content") ,

    // Pole z informacjami
    info_iter: document.getElementById("gui-info_iter") ,
    info_best: document.getElementById("gui-info_best") ,
    info_state: document.getElementById("gui-info_state") ,
    btn_state: document.getElementById("gui-btn_state") ,
    btn_refresh: document.getElementById("gui-btn_refresh") ,
    
    // Pole dostosowania funkcji
    select_fun: document.getElementById("gui-select_fun") ,
    check_negatives: document.getElementById("gui-check_negatives") ,
    select_direction: document.getElementById("gui-select_direction") ,
    lbl_range_delay: document.getElementById("gui-lbl_range_delay") ,
    range_delay: document.getElementById("gui-range_delay") ,
    nof_iterations: document.getElementById("gui-nof_iterations") ,
    check_3d: document.getElementById("gui-check_3d") ,

    // Zakresy
    nof_minx: document.getElementById("gui-nof_minx") ,
    nof_maxx: document.getElementById("gui-nof_maxx") ,
    nof_miny: document.getElementById("gui-nof_miny") ,
    nof_maxy: document.getElementById("gui-nof_maxy") ,
    nof_speed: document.getElementById("gui-nof_speed") ,

    // Ustawienia algorytmu
    nof_particles: document.getElementById("gui-nof_particles") ,
    nof_interia: document.getElementById("gui-nof_interia") ,
    nof_ginfl: document.getElementById("gui-nof_ginfl") ,
    nof_linfl: document.getElementById("gui-nof_linfl") ,
    nof_tolerr: document.getElementById("gui-nof_tolerr") ,

    // Pole wybory wyglądu
    select_theme: document.getElementById("gui-select_theme") ,
    btn_part_color: document.getElementById("gui-btn_part_color") ,

    // Kontener wykresu
    cont_plot: document.getElementById("gui-cont_plot")
};

const PLOT_LAY = {
    autosize: true ,
    hovermode: false ,
    showlegend: false ,
    margin: { l: 0 ,  r: 0 , t: 0 , b: 0 }
};
const PLOT_DAT = {
    type: "contour" ,
    showscale: false ,
    contours: {
        x: { highlight: false } ,
        y: { highlight: false } ,
        z: { highlight: false }
    }
};
const PLOT_CFG = {
    displayModeBar: false ,
    responsive: true
};

let CurrentFun = null;
let reverse_fun = false;
let UpdateRequired = false;

///////////////////////////////////////////////////////////////////////////////////////////////////

window.addEventListener("load" , () => {

    // Reset
    GUI.nof_iterations.value = 10;
    GUI.check_3d.checked = false;
    GUI.check_negatives.checked = false;
    GUI.range_delay.value = 500;
    GUI.range_delay.dispatchEvent(new Event('change'));
    GUI.nof_particles.value = 10;
    GUI.nof_interia.value = 0.5;
    GUI.nof_ginfl.value = 1.5;
    GUI.nof_linfl.value = 1.0;
    GUI.nof_tolerr.value = "";
    GUI.btn_part_color.value = "#FF0000";

    // Tworzenie listy funkcji
    for (let k in FUNCTIONS) {
        
        // Zabezpieczenie przed sprawdzaniem prymitywów
        if (!FUNCTIONS.hasOwnProperty(k) || FUNCTIONS[k].name === null) {
            continue;
        } else {

            // Dodawanie nowego elementu
            let item = document.createElement("option");
            item.innerHTML = FUNCTIONS[k].name;
            GUI.select_fun.appendChild(item);
        }
    }

    // Wybieranie funkcji z listy
    GUI.select_fun.selectedIndex = 0;
    CurrentFun = getFunctionFromName(GUI.select_fun.value);
    applySelectedFunction();

});

GUI.select_fun.addEventListener("change" , () => {
    CurrentFun = getFunctionFromName(GUI.select_fun.value);
    applySelectedFunction();
});

GUI.check_negatives.addEventListener("change" , () => {

    reverse_fun = GUI.check_negatives.checked ? true : false ;
    generatePlot();

});

GUI.range_delay.addEventListener("change" , () => {

    let v = GUI.range_delay.valueAsNumber;
    GUI.lbl_range_delay.innerHTML = `Opóźnienie (${v / 1000}s)`;

});

GUI.check_3d.addEventListener("click" , () => {

    PLOT_DAT.type = GUI.check_3d.checked ? "surface" : "contour"; 
    generatePlot();

});

GUI.select_theme.addEventListener("change" , () => {
    generatePlot();
});

GUI.nof_tolerr.addEventListener("change" , () => {
    if (GUI.nof_tolerr.value <= 0) {
        GUI.nof_tolerr.value = "";
    }
});

GUI.btn_refresh.addEventListener("click" , () => {

    generatePlot();

});

GUI.btn_state.addEventListener("click" , () => {

    let algorithm = new PSO( {
    
        swarmSize:          GUI.nof_particles.valueAsNumber ,
        epochesLimit:       GUI.nof_iterations.valueAsNumber ,
        calculateError:     CurrentFun.calculate ,

        ranges: [
            { minimum: GUI.nof_minx.valueAsNumber , maximum: GUI.nof_maxx.valueAsNumber } ,
            { minimum: GUI.nof_miny.valueAsNumber , maximum: GUI.nof_maxy.valueAsNumber }
        ],
        particleSpeed: GUI.nof_speed.valueAsNumber ,

        particleInteria: GUI.nof_interia.valueAsNumber ,
        globalAcceleration: GUI.nof_ginfl.valueAsNumber ,
        localAcceleration: GUI.nof_linfl.valueAsNumber ,
        toleratedError: GUI.nof_tolerr.valueAsNumber ,

        onIterationFinished: function(epochIndex, bestGlobalSolution) {
            var error = bestGlobalSolution.error;
            var position = bestGlobalSolution.position;
    
            console.log(epochIndex + '\t' + error + '\t[' + position + ']');
        }
    
    });

    
    console.log('[epoch]\t[error]\t\t\t[position]\n');

    let result = algorithm.start();

    console.log('-------------------------------');
    console.log('Solution:');
    console.log('  error: ' + result.error.toFixed(10));
    console.log('  position: ' + result.position);

});


///////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Wykonuje czynności z wybieraniem funkcji z listy.
 * @throws {Error} Jeżeli nie odnaleziono funkcji.
*/
function applySelectedFunction() {
    
    if (CurrentFun === null) {
        throw new Error("Nie wybrano funkcji.");
    }

    // Ustawianie zakresów
    GUI.nof_minx.value = CurrentFun.x[0];
    GUI.nof_maxx.value = CurrentFun.x[1];
    GUI.nof_miny.value = CurrentFun.y[0];
    GUI.nof_maxy.value = CurrentFun.y[1];
    GUI.nof_speed.value = CurrentFun.inc;

    generatePlot();
}

async function generatePlot() {

    // Obiekt, który zawiera dane wykresu
    let ret = { x_arr: [] , y_arr: [] , z_mat: [] };

    // Obiekt, który zawiera wartści zasięgów podane w GUI
    let fields = {
        xmin: GUI.nof_minx.valueAsNumber , 
        xmax: GUI.nof_maxx.valueAsNumber , 
        ymin: GUI.nof_miny.valueAsNumber , 
        ymax: GUI.nof_maxy.valueAsNumber , 
    };

    // Walidacja pól
    if (fields.xmin >= fields.xmax || (fields.xmin + CurrentFun.inc * 2) >= fields.xmax ) {
        throw new Error("Różnica między Xmin i Xmax jest nieprawidłowa lub za mała");
    } else if (fields.ymin >= fields.ymax || (fields.ymin + CurrentFun.inc * 2) >= fields.ymax ) {
        throw new Error("Różnica między Ymin i Ymax jest nieprawidłowa lub za mała");
    }

    // Generowanie X-ów
    let curr = fields.xmin;
    while (curr <= fields.xmax) {
        ret.x_arr.push(curr);
        curr += CurrentFun.inc;
    }
    
    // Generowanie Y-ów
    curr = fields.ymin;
    while (curr <= fields.ymax) {
        ret.y_arr.push(curr);
        curr += CurrentFun.inc;
    }

    // Generowanie powierzchni
    for (let i = 0 ; i < ret.x_arr.length ; i++) {
        
        let row = [];

        for (let j = 0 , v = null ; j < ret.y_arr.length ; j++) {
            v = CurrentFun.calculate(ret.x_arr[i] , ret.y_arr[j]);
            row.push(reverse_fun ? -v : v);
        }

        ret.z_mat.push(row);

    }

    // Ustawienie danych
    PLOT_DAT.x = ret.x_arr;
    PLOT_DAT.y = ret.y_arr;
    PLOT_DAT.z = ret.z_mat;

    // Ustawienie kolorów
    PLOT_DAT.colorscale = GUI.select_theme.value;

    // Generowanie
    Plotly.react(GUI.cont_plot , [ PLOT_DAT ] , PLOT_LAY , PLOT_CFG);
}